<?php

/**
 * Fired during plugin deactivation
 *
 * @link       www.hexacom.com
 * @since      1.0.0
 *
 * @package    Eb_Calendar_Form
 * @subpackage Eb_Calendar_Form/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Eb_Calendar_Form
 * @subpackage Eb_Calendar_Form/includes
 * @author     Eduar Berroteran <berroterane@gmail.com>
 */
class Eb_Calendar_Form_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
